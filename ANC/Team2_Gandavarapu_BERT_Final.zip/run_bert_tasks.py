# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 19:32:53 2022

@author: Sensei-NDES2

Original script taken from https://www.tensorflow.org/text/tutorials/bert_glue
Heavily amended for project use
"""

import time

import os                              # For file and filepath handling
import sys                             # For writing to files for our outputs
import tensorflow as tf                # Tensorflow for tensor/text/etc. processing
import tensorflow_hub as hub           # Repo of trained models
import tensorflow_datasets as tfds     # Datasets to pull from
import tensorflow_text as text         # A dependency of the preprocessing model
import tensorflow_addons as tfa        # Imported for getting some metrics for the configuration of the model optimizer for some tasks
from official.nlp import optimization
import numpy as np

# Our metrics for the non-accuracy-based GLUE scores
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import f1_score, matthews_corrcoef

# Import the Huggingface datasets library for calculating the metrics of all of the GLUE scores.
# Follow this link for installation instructions
# (be sure to follow the instructions to install with pip):
# https://huggingface.co/docs/datasets/installation
import datasets as hf_datasets

start_time = time.time()

original_stdout = sys.stdout # Save a reference to the original standard output

tf.get_logger().setLevel('ERROR')

if tf.config.list_physical_devices('GPU'):
  strategy = tf.distribute.MirroredStrategy()
  print('Using GPU')
else:
  raise ValueError('Running on CPU is not recommended.')
  
# =========================================================== #
# =========================================================== #
# ================= SET THE BERT MODEL NAME ================= # 
# =========================================================== #

# Chosen from the 'map_name_to_handle' dict below             #
bert_model_name = 'small_bert/bert_en_uncased_L-8_H-512_A-8'  #

# =========================================================== #
# =========================================================== #


# Map the name to the url to get the BERT model from
map_name_to_handle = {
    'bert_en_uncased_L-12_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_uncased_L-12_H-768_A-12/3',
    'bert_en_uncased_L-24_H-1024_A-16':
        'https://tfhub.dev/tensorflow/bert_en_uncased_L-24_H-1024_A-16/3',
    'bert_en_wwm_uncased_L-24_H-1024_A-16':
        'https://tfhub.dev/tensorflow/bert_en_wwm_uncased_L-24_H-1024_A-16/3',
    'bert_en_cased_L-12_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_cased_L-12_H-768_A-12/3',
    'bert_en_cased_L-24_H-1024_A-16':
        'https://tfhub.dev/tensorflow/bert_en_cased_L-24_H-1024_A-16/3',
    'bert_en_wwm_cased_L-24_H-1024_A-16':
        'https://tfhub.dev/tensorflow/bert_en_wwm_cased_L-24_H-1024_A-16/3',
    'bert_multi_cased_L-12_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_multi_cased_L-12_H-768_A-12/3',
    'small_bert/bert_en_uncased_L-2_H-128_A-2':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-2_H-128_A-2/1',
    'small_bert/bert_en_uncased_L-2_H-256_A-4':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-2_H-256_A-4/1',
    'small_bert/bert_en_uncased_L-2_H-512_A-8':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-2_H-512_A-8/1',
    'small_bert/bert_en_uncased_L-2_H-768_A-12':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-2_H-768_A-12/1',
    'small_bert/bert_en_uncased_L-4_H-128_A-2':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-4_H-128_A-2/1',
    'small_bert/bert_en_uncased_L-4_H-256_A-4':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-4_H-256_A-4/1',
    'small_bert/bert_en_uncased_L-4_H-512_A-8':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-4_H-512_A-8/1',
    'small_bert/bert_en_uncased_L-4_H-768_A-12':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-4_H-768_A-12/1',
    'small_bert/bert_en_uncased_L-6_H-128_A-2':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-6_H-128_A-2/1',
    'small_bert/bert_en_uncased_L-6_H-256_A-4':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-6_H-256_A-4/1',
    'small_bert/bert_en_uncased_L-6_H-512_A-8':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-6_H-512_A-8/1',
    'small_bert/bert_en_uncased_L-6_H-768_A-12':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-6_H-768_A-12/1',
    'small_bert/bert_en_uncased_L-8_H-128_A-2':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-8_H-128_A-2/1',
    'small_bert/bert_en_uncased_L-8_H-256_A-4':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-8_H-256_A-4/1',
    'small_bert/bert_en_uncased_L-8_H-512_A-8':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-8_H-512_A-8/1',
    'small_bert/bert_en_uncased_L-8_H-768_A-12':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-8_H-768_A-12/1',
    'small_bert/bert_en_uncased_L-10_H-128_A-2':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-10_H-128_A-2/1',
    'small_bert/bert_en_uncased_L-10_H-256_A-4':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-10_H-256_A-4/1',
    'small_bert/bert_en_uncased_L-10_H-512_A-8':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-10_H-512_A-8/1',
    'small_bert/bert_en_uncased_L-10_H-768_A-12':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-10_H-768_A-12/1',
    'small_bert/bert_en_uncased_L-12_H-128_A-2':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-12_H-128_A-2/1',
    'small_bert/bert_en_uncased_L-12_H-256_A-4':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-12_H-256_A-4/1',
    'small_bert/bert_en_uncased_L-12_H-512_A-8':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-12_H-512_A-8/1',
    'small_bert/bert_en_uncased_L-12_H-768_A-12':
        'https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-12_H-768_A-12/1',
    'albert_en_base':
        'https://tfhub.dev/tensorflow/albert_en_base/2',
    'albert_en_large':
        'https://tfhub.dev/tensorflow/albert_en_large/2',
    'albert_en_xlarge':
        'https://tfhub.dev/tensorflow/albert_en_xlarge/2',
    'albert_en_xxlarge':
        'https://tfhub.dev/tensorflow/albert_en_xxlarge/2',
    'electra_small':
        'https://tfhub.dev/google/electra_small/2',
    'electra_base':
        'https://tfhub.dev/google/electra_base/2',
    'experts_pubmed':
        'https://tfhub.dev/google/experts/bert/pubmed/2',
    'experts_wiki_books':
        'https://tfhub.dev/google/experts/bert/wiki_books/2',
    'talking-heads_base':
        'https://tfhub.dev/tensorflow/talkheads_ggelu_bert_en_base/1',
    'talking-heads_large':
        'https://tfhub.dev/tensorflow/talkheads_ggelu_bert_en_large/1',
}

# Map the chosen model to the corresponding preprocess model
map_model_to_preprocess = {
    'bert_en_uncased_L-24_H-1024_A-16':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'bert_en_uncased_L-12_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'bert_en_wwm_cased_L-24_H-1024_A-16':
        'https://tfhub.dev/tensorflow/bert_en_cased_preprocess/3',
    'bert_en_cased_L-24_H-1024_A-16':
        'https://tfhub.dev/tensorflow/bert_en_cased_preprocess/3',
    'bert_en_cased_L-12_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_cased_preprocess/3',
    'bert_en_wwm_uncased_L-24_H-1024_A-16':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-2_H-128_A-2':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-2_H-256_A-4':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-2_H-512_A-8':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-2_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-4_H-128_A-2':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-4_H-256_A-4':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-4_H-512_A-8':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-4_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-6_H-128_A-2':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-6_H-256_A-4':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-6_H-512_A-8':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-6_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-8_H-128_A-2':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-8_H-256_A-4':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-8_H-512_A-8':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-8_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-10_H-128_A-2':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-10_H-256_A-4':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-10_H-512_A-8':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-10_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-12_H-128_A-2':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-12_H-256_A-4':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-12_H-512_A-8':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'small_bert/bert_en_uncased_L-12_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'bert_multi_cased_L-12_H-768_A-12':
        'https://tfhub.dev/tensorflow/bert_multi_cased_preprocess/3',
    'albert_en_base':
        'https://tfhub.dev/tensorflow/albert_en_preprocess/3',
    'albert_en_large':
        'https://tfhub.dev/tensorflow/albert_en_preprocess/3',
    'albert_en_xlarge':
        'https://tfhub.dev/tensorflow/albert_en_preprocess/3',
    'albert_en_xxlarge':
        'https://tfhub.dev/tensorflow/albert_en_preprocess/3',
    'electra_small':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'electra_base':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'experts_pubmed':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'experts_wiki_books':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'talking-heads_base':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
    'talking-heads_large':
        'https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3',
}

# Get the appropriate URLs for the BERT model and its correpsonding preprocessing model
tfhub_handle_encoder = map_name_to_handle[bert_model_name]
tfhub_handle_preprocess = map_model_to_preprocess[bert_model_name]

print('BERT model selected           :', tfhub_handle_encoder)
print('Preprocessing model auto-selected:', tfhub_handle_preprocess)

bert_preprocess = hub.load(tfhub_handle_preprocess)
# Test preprocessing model with sample text
tok = bert_preprocess.tokenize(tf.constant(['Hello TensorFlow!']))
print(tok)

text_preprocessed = bert_preprocess.bert_pack_inputs([tok, tok], tf.constant(20))

print('Shape Word Ids : ', text_preprocessed['input_word_ids'].shape)
print('Word Ids       : ', text_preprocessed['input_word_ids'][0, :16])
print('Shape Mask     : ', text_preprocessed['input_mask'].shape)
print('Input Mask     : ', text_preprocessed['input_mask'][0, :16])
print('Shape Type Ids : ', text_preprocessed['input_type_ids'].shape)
print('Type Ids       : ', text_preprocessed['input_type_ids'][0, :16])

def make_bert_preprocess_model(sentence_features, seq_length=128):
  """Returns Model mapping string features to BERT inputs.

  Args:
    sentence_features: a list with the names of string-valued features.
    seq_length: an integer that defines the sequence length of BERT inputs.

  Returns:
    A Keras Model that can be called on a list or dict of string Tensors
    (with the order or names, resp., given by sentence_features) and
    returns a dict of tensors for input to BERT.
  """

  input_segments = [
      tf.keras.layers.Input(shape=(), dtype=tf.string, name=ft)
      for ft in sentence_features]

  # Tokenize the text to word pieces.
  bert_preprocess = hub.load(tfhub_handle_preprocess)
  tokenizer = hub.KerasLayer(bert_preprocess.tokenize, name='tokenizer')
  segments = [tokenizer(s) for s in input_segments]

  # Optional: Trim segments in a smart way to fit seq_length.
  # Simple cases (like this example) can skip this step and let
  # the next step apply a default truncation to approximately equal lengths.
  truncated_segments = segments

  # Pack inputs. The details (start/end token ids, dict of output tensors)
  # are model-dependent, so this gets loaded from the SavedModel.
  packer = hub.KerasLayer(bert_preprocess.bert_pack_inputs,
                          arguments=dict(seq_length=seq_length),
                          name='packer')
  model_inputs = packer(truncated_segments)
  return tf.keras.Model(input_segments, model_inputs)

# Further test the preprocessing model chosen
test_preprocess_model = make_bert_preprocess_model(['my_input1', 'my_input2'])
test_text = [np.array(['some random test sentence']),
             np.array(['another sentence'])]
text_preprocessed = test_preprocess_model(test_text)

print('Keys           : ', list(text_preprocessed.keys()))
print('Shape Word Ids : ', text_preprocessed['input_word_ids'].shape)
print('Word Ids       : ', text_preprocessed['input_word_ids'][0, :16])
print('Shape Mask     : ', text_preprocessed['input_mask'].shape)
print('Input Mask     : ', text_preprocessed['input_mask'][0, :16])
print('Shape Type Ids : ', text_preprocessed['input_type_ids'].shape)
print('Type Ids       : ', text_preprocessed['input_type_ids'][0, :16])

# Plot the chosen preprocessing model visually
tf.keras.utils.plot_model(test_preprocess_model, show_shapes=True, show_dtype=True)

AUTOTUNE = tf.data.AUTOTUNE


def load_dataset_from_tfds(given_dataset, info, batch_size,
                           train_proportion, validation_proportion, test_proportion,
                           bert_preprocess_model):
  """
  # load_dataset_from_tfds

  Function Description:
    Given a dataset formed from the training or validation split
    (or a concatenation thereof) of a given tensorflow dataset
    (specified by tfds_name as seen below) taken from the online
    repo of datasets, splits the given dataset into training,
    validation, and test splits.
    Used to generate labeled splits seeing as how the original
    datasets have unlabeled test splits.

  Args:
    given_dataset - The dataset for this function to handle.
    info - The info about the original tensorflow dataset  (specified by tfds_name) loaded from its .json, grabbed by using tfds.builder(tfds_name).info
    batch_size - Batch size to load the dataset into memory.
    bert_preprocess_model - The preprocessing model to map the resultant splits to.

  Returns:
    dataset - The full dataset that was inserted into the function, converted from a dict to a dataset using tf.data.Dataset.from_tensor_slices.
    num_examples - The number of examples in the concatenation of the training and validation splits of the original dataset defined by tfds_name.
    train_dataset - The resulting training split dataset taken from given_dataset.
    train_data_size - The number of samples in train_dataset.
    validation_dataset - The resulting validation split dataset taken from given_dataset.
    validation_data_size - The number of samples in validation_dataset.
    test_dataset - The resulting test split dataset taken from given_dataset.
    test_data_size - The number of samples in test_dataset.
  """
  
  dataset = tf.data.Dataset.from_tensor_slices(given_dataset) # Get the input dataset into tensorflow dataset form
  num_examples = info.splits[train_split].num_examples + info.splits[validation_split].num_examples # Get the total number of training and validation samples in the original dataset
  slice_dataset_size = len(given_dataset['label']) # Get the number of examples in the input dataset
  
  train_split_proportion = train_proportion # Calculate the proportion of given_dataset to take for training
  validation_split_proportion = validation_proportion # Calculate the proportion of given_dataset to take for validation
  test_split_proportion = 1 - (train_proportion + validation_proportion) # Calculate the proportion of given_dataset to take for testing
  
  # Print the dataset elements and the total amount of elements in the input dataset for verification...
  print("Outputs of the input dataset...")
  num_d = 0
  for element in dataset:
      num_d += 1
      #print(num_d)
      #print("Current training element's label:")
      #print(element['label'].numpy())
      #rint(element['sentence'].numpy())
  print("Counted elements pre-shuffle:")
  print(num_d)

  # Shuffle the training dataset
  dataset = dataset.shuffle(buffer_size = num_examples, reshuffle_each_iteration=False)
  
  # Print the dataset elements and the total amount of elements in the input dataset after shuffling for verification...
  print("Outputs of the training split after shuffling...")
  num_d2 = 0
  for element in dataset:
      num_d2 += 1
      #print(num_d2)
      #print("Current training element's label:")
      #print(element['label'].numpy())
      #print(element['sentence'].numpy())
  print("Post shuffled split:")
  print(num_d2)
  
  # Take the input dataset and split into train, test, and validation subsets
  train_data_size = int(train_split_proportion * slice_dataset_size)
  validation_data_size = int(validation_split_proportion * slice_dataset_size)
  test_data_size = int(test_split_proportion * num_examples)
  train_dataset = dataset.take(train_data_size)
  test_dataset = dataset.skip(train_data_size)
  validation_dataset = test_dataset.skip(validation_data_size)
  test_dataset = test_dataset.take(test_data_size)
  
  # Print the details of the test dataset for verification
  print("Test dataset:")
  print(test_dataset)
  print("Test dataset size:")
  
  # Get the sentence features from info
  sentence_features_orig_f = list(info.features.keys())
  # Print the dataset elements in the test split for verification purposes
  print("Outputs of the training.test split...")
  num_test = 0
  with open('test_split_labels.txt', 'w') as f:
    sys.stdout = f # Change the standard output to the file we created.
    print("Test Labels:")
    print("ID | Label | Sentence(s)")
    for element in test_dataset:
        num_test += 1
        sample_sentence = ""
        if 'sentence' in sentence_features_orig_f:
          sample_sentence += str(element['sentence'])
        if 'sentence1' in sentence_features_orig_f:
          sample_sentence += str(element['sentence1'])
        if 'sentence2' in sentence_features_orig_f:
          sample_sentence += " /// " + str(element['sentence2'])
        if 'premise' in sentence_features_orig_f:
          sample_sentence += str(element['premise'])
        if 'hypothesis' in sentence_features_orig_f:
          sample_sentence += " /// " + str(element['hypothesis'])
        print(str(element['idx'].numpy()) + ' | ' + str(element['label'].numpy()) + ' | ' + str(sample_sentence))
    sys.stdout = original_stdout # Reset the standard output to its original value
  print("Number of test samples printed:")
  print(num_test)

  # Map the dataset to the input model
  dataset = dataset.batch(batch_size)
  dataset = dataset.map(lambda ex: (bert_preprocess_model(ex), ex['label']))
  dataset = dataset.cache().prefetch(buffer_size=AUTOTUNE)
  
  # Map the training and validation splits to the input model
  train_dataset = train_dataset.batch(batch_size)
  train_dataset = train_dataset.map(lambda ex: (bert_preprocess_model(ex), ex['label']))
  train_dataset = train_dataset.cache().prefetch(buffer_size=AUTOTUNE)
  validation_dataset = validation_dataset.batch(batch_size)
  validation_dataset = validation_dataset.map(lambda ex: (bert_preprocess_model(ex), ex['label']))
  validation_dataset = validation_dataset.cache().prefetch(buffer_size=AUTOTUNE)
  # The test dataset will be mapped to the model later
  return dataset, num_examples, train_dataset, train_data_size, validation_dataset, validation_data_size, test_dataset, test_data_size

def build_classifier_model(num_classes):

  class Classifier(tf.keras.Model):
    def __init__(self, num_classes):
      super(Classifier, self).__init__(name="prediction")
      self.encoder = hub.KerasLayer(tfhub_handle_encoder, trainable=True)
      self.dropout = tf.keras.layers.Dropout(0.1)
      self.dense = tf.keras.layers.Dense(num_classes)

    def call(self, preprocessed_text):
      encoder_outputs = self.encoder(preprocessed_text)
      pooled_output = encoder_outputs["pooled_output"]
      x = self.dropout(pooled_output)
      x = self.dense(x)
      return x

  model = Classifier(num_classes)
  return model

test_classifier_model = build_classifier_model(2)
bert_raw_result = test_classifier_model(text_preprocessed)
print(tf.sigmoid(bert_raw_result))




# ============================================ #
# ============================================ #
# ========== SET THE TASK NAME HERE ========== #
# ============================================ #

task_name = 'qqp'                             #

# ============================================ #
# ============================================ #
# ============================================ #

# Sets the filename prefix given the task name and currently selected model; replace any slashes with triple-hyphens
filename_prefix = bert_model_name.replace("/","---") + "___" + task_name

# Sets the tensorflow dataset name given the task name
tfds_name = 'glue/' + task_name

with tf.device('/job:localhost'):
  # batch_size=-1 is a way to load the dataset into memory
  # Load the tensorflow dataset defined by tfds_name
  in_memory_ds, tfds_info = tfds.load(tfds_name, batch_size=-1, shuffle_files=True, with_info=True)
  # Load our own dataset by concatenating the train and validation splits of the tfds_name dataset
  if tfds_name == 'glue/mnli':
      trval_memory_ds = tfds.load(tfds_name, batch_size=-1, split='train+validation_matched', shuffle_files=True)
  else:
      trval_memory_ds = tfds.load(tfds_name, batch_size=-1, split='train+validation', shuffle_files=True)

# Below line doesn't properly get the builder info for some tasks, so we use the tfds_info in the tuple above
#tfds_info = tfds.builder(tfds_name).info # Get the dataset info

sentence_features_orig = list(tfds_info.features.keys())
sentence_features = list(tfds_info.features.keys())
sentence_features.remove('idx')
sentence_features.remove('label')

# Get the splits of the tensorflow dataset and set variables to hold the names of those splits
available_splits = list(tfds_info.splits.keys())
train_split = 'train'
validation_split = 'validation'
test_split = 'test'
if tfds_name == 'glue/mnli':
  validation_split = 'validation_matched'
  test_split = 'test_matched'

# Get the number of classes and examples in the tensorflow dataset
num_classes = tfds_info.features['label'].num_classes
num_examples = tfds_info.splits.total_num_examples

# Get the number of training, validation, and test samples in the original dataset
num_orig_train_samples = tfds_info.splits[train_split].num_examples
num_orig_validation_samples = tfds_info.splits[validation_split].num_examples
num_orig_test_samples = tfds_info.splits[test_split].num_examples

# Calculate proportion of training, validation, and test samples in the original dataset so we can use a similar ratio for our own splits
orig_train_proportion = num_orig_train_samples / num_examples
orig_validation_proportion = num_orig_validation_samples / num_examples
orig_test_proportion = num_orig_test_samples / num_examples

print(f'Using {tfds_name} from TFDS')
print(f'This dataset has {num_examples} examples')
print(f'Number of classes: {num_classes}')
print(f'Features {sentence_features}')
print(f'Splits {available_splits}')

# =============================================================================
# =============================================================================
# =============================================================================
# The code below is just to show some samples from the selected dataset
print(f'Here are some sample rows from {tfds_name} dataset')
sample_dataset = tf.data.Dataset.from_tensor_slices(in_memory_ds[train_split])

labels_names = tfds_info.features['label'].names
print(labels_names)
print()

sample_i = 1
for sample_row in sample_dataset.take(5):
  samples = [sample_row[feature] for feature in sentence_features]
  print(f'sample row {sample_i}')
  for sample in samples:
    print(sample.numpy())
  sample_label = sample_row['label']

  print(f'label: {sample_label} ({labels_names[sample_label]})')
  print()
  sample_i += 1
# =============================================================================
# =============================================================================
# =============================================================================



def get_configuration(glue_task):

  loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)

  if glue_task == 'glue/cola':
    metrics = tfa.metrics.MatthewsCorrelationCoefficient(num_classes=2)
  else:
    metrics = tf.keras.metrics.SparseCategoricalAccuracy(
        'accuracy', dtype=tf.float32)

  return metrics, loss

# Set the parameters for the optimizer and model fit
epochs = 4
batch_size = 32
init_lr = 3e-4

print(f'Fine tuning {tfhub_handle_encoder} model')
bert_preprocess_model = make_bert_preprocess_model(sentence_features)

with strategy.scope():

  # metric have to be created inside the strategy scope
  metrics, loss = get_configuration(tfds_name)

  # Get the training split from the original dataset and then make our own splits from that
  dataset, data_size, train_dataset, train_data_size, validation_dataset, validation_data_size, test_dataset_r, test_data_size = load_dataset_from_tfds(
      trval_memory_ds, tfds_info, batch_size, orig_train_proportion, orig_validation_proportion, orig_test_proportion, bert_preprocess_model)
  
  # Set up the optimizer and model fit parameters
  steps_per_epoch = train_data_size // batch_size
  num_train_steps = steps_per_epoch * epochs
  num_warmup_steps = num_train_steps // 10
  
  # Set the validation steps
  validation_steps = validation_data_size // batch_size
  
  # Build the model
  classifier_model = build_classifier_model(num_classes)

  # Optimize the model
  optimizer = optimization.create_optimizer(
      init_lr=init_lr,
      num_train_steps=num_train_steps,
      num_warmup_steps=num_warmup_steps,
      optimizer_type='adamw')
  
  # Compile the model with our given parameters
  classifier_model.compile(optimizer=optimizer, loss=loss, metrics=[metrics])

  # Compile the model, training and validating on our given datasets
  classifier_model.fit(
      x=train_dataset,
      validation_data=validation_dataset,
      #steps_per_epoch=steps_per_epoch,
      epochs=epochs,
      validation_steps=validation_steps)

# ====================================================================================== #
# =================================== SAVE THE MODEL =================================== #
# ====================================================================================== #
main_save_path = './my_models'
bert_type = tfhub_handle_encoder.split('/')[-2]
saved_model_name = f'{tfds_name.replace("/", "_")}_{bert_type}'

saved_model_path = os.path.join(main_save_path, saved_model_name)

preprocess_inputs = bert_preprocess_model.inputs
bert_encoder_inputs = bert_preprocess_model(preprocess_inputs)
bert_outputs = classifier_model(bert_encoder_inputs)
model_for_export = tf.keras.Model(preprocess_inputs, bert_outputs)

print('Saving', saved_model_path)

# Save everything on the Colab host (even the variables from TPU memory)
save_options = tf.saved_model.SaveOptions(experimental_io_device='/job:localhost')
model_for_export.save(saved_model_path, include_optimizer=False,
                      options=save_options)
# ====================================================================================== #
# ====================================================================================== #
# ====================================================================================== #


# Reload the saved model
with tf.device('/job:localhost'):
  reloaded_model = tf.saved_model.load(saved_model_path)
  
# ============================================================ #  
# === Functions for mapping the test inputs to the model       #
# ============================================================ #
def prepare(record):
  model_inputs = [[record[ft]] for ft in sentence_features]
  return model_inputs


def prepare_serving(record):
  model_inputs = {ft: record[ft] for ft in sentence_features}
  return model_inputs
# ============================================================ #


def print_bert_results_classified(test, bert_result, dataset_name):
  """
  # print_bert_results_classified
  Function Description:
    Given a test sample, its resultant tensors after being fed into a BERT
    model, and the respective task, outputs the phrase and its  classification
    based on the chosen task, and returns that classification.

  Args:
    test - The test sample to output the result for.
    bert_result - The output tensor after feeding test into a BERT model.
    dataset_name - The appropriate dataset/task that matches test and bert_result.

  Returns:
    bert_result_class - The numerical classification of 'test'.
  """
  bert_result_class = tf.argmax(bert_result, axis=1)[0]

  if dataset_name == 'glue/cola':
    print('sentence:', test[0].numpy())
    if bert_result_class == 1:
      print('This sentence is acceptable')
    else:
      print('This sentence is unacceptable')

  elif dataset_name == 'glue/sst2':
    print('sentence:', test[0])
    if bert_result_class == 1:
      print('This sentence has POSITIVE sentiment')
    else:
      print('This sentence has NEGATIVE sentiment')

  elif dataset_name == 'glue/mrpc':
    print('sentence1:', test[0])
    print('sentence2:', test[1])
    if bert_result_class == 1:
      print('Are a paraphrase')
    else:
      print('Are NOT a paraphrase')

  elif dataset_name == 'glue/qqp':
    print('question1:', test[0])
    print('question2:', test[1])
    if bert_result_class == 1:
      print('Questions are similar')
    else:
      print('Questions are NOT similar')

  elif dataset_name == 'glue/mnli':
    print('premise   :', test[0])
    print('hypothesis:', test[1])
    if bert_result_class == 1:
      print('This premise is NEUTRAL to the hypothesis')
    elif bert_result_class == 2:
      print('This premise CONTRADICTS the hypothesis')
    else:
      print('This premise ENTAILS the hypothesis')

  elif dataset_name == 'glue/qnli':
    print('question:', test[0])
    print('sentence:', test[1])
    if bert_result_class == 1:
      print('The question is NOT answerable by the sentence')
    else:
      print('The question is answerable by the sentence')

  elif dataset_name == 'glue/rte':
    print('sentence1:', test[0])
    print('sentence2:', test[1])
    if bert_result_class == 1:
      print('Sentence1 DOES NOT entails sentence2')
    else:
      print('Sentence1 entails sentence2')

  elif dataset_name == 'glue/wnli':
    print('sentence1:', test[0])
    print('sentence2:', test[1])
    if bert_result_class == 1:
      print('Sentence1 DOES NOT entails sentence2')
    else:
      print('Sentence1 entails sentence2')

  print('BERT raw results:', bert_result[0])
  print()
  
  return bert_result_class
  

# Make a blank list to hold the test split's labels
test_split_class_list = []
# Filename for outputting the test split's information to
returned_test_split_info_filename = filename_prefix + '_' + 'test_split_returned_info.txt'

# Print the dataset elements in the test split that was returned by the load function from earlier
print("Outputs of the training.test split that was returned...")
num_test_r = 0
with open(returned_test_split_info_filename, 'w') as f:
  sys.stdout = f # Change the standard output to the file we created.
  print("Test Split Samples:")
  print("ID | Label | Sentence(s)")
  for element in test_dataset_r:
      num_test_r += 1
      sample_sentence = ""
      if 'sentence' in sentence_features_orig:
        sample_sentence += str(element['sentence'])
      if 'sentence1' in sentence_features_orig:
        sample_sentence += str(element['sentence1'])
      if 'sentence2' in sentence_features_orig:
        sample_sentence += " /// " + str(element['sentence2'])
      if 'premise' in sentence_features_orig:
        sample_sentence += str(element['premise'])
      if 'hypothesis' in sentence_features_orig:
        sample_sentence += " /// " + str(element['hypothesis'])
      print(str(element['idx'].numpy()) + ' | ' + str(element['label'].numpy()) + ' | ' + str(sample_sentence))
      test_split_class_list.append(element['label'].numpy())
  sys.stdout = original_stdout # Reset the standard output to its original value
print("Number of test samples printed:")
print(num_test_r)

# Make a blank list to hold the test results
test_predictions_class_list = []

# Filename for outputting the test results' information to
test_run_results_filename = filename_prefix + '_' + 'test_run_results.txt'

with tf.device('/job:localhost'):
  # Classify the whole test split...
  print("Generating test results...")
  num_test_row = 1
  # Print the list of the test results to a file
  test_run_dataset = test_dataset_r.map(prepare)
  with open(test_run_results_filename, 'w') as f:
    sys.stdout = f # Change the standard output to the file we created.
    print("========== OUTPUT OF TEST RUN ==========")
    for test_row in test_run_dataset:
      print("Sample " + str(num_test_row) + "...")
      if len(sentence_features) == 1:
        result = reloaded_model(test_row[0])
      else:
        result = reloaded_model(list(test_row))

      test_predictions_class_list.append(print_bert_results_classified(test_row, result, tfds_name).numpy())
      num_test_row +=1
    sys.stdout = original_stdout # Reset the standard output to its original value

# Filename for outputting the test split's raw labels to
test_split_labels_filename = filename_prefix + '_' + 'test_split_labels_prerun.txt'

# Print the list of the classes of each test sample to a file
with open(test_split_labels_filename, 'w') as f:
  sys.stdout = f # Change the standard output to the file we created.
  print("The Original Test Split Labels:")
  #print("ID | Label")
  for result in test_split_class_list:
      print(result)
  sys.stdout = original_stdout # Reset the standard output to its original value


# Filename for outputting the test split's raw labels to
test_run_classified_labels_filename = filename_prefix + '_' + 'test_run_labels_model-classified.txt'
# Print the list of the classes of each classified test sample from the test run to a file
with open(test_run_classified_labels_filename, 'w') as f:
  sys.stdout = f # Change the standard output to the file we created.
  print("Test Run Labels:")
  #print("ID | Label")
  for result in test_predictions_class_list:
      print(result)
  sys.stdout = original_stdout # Reset the standard output to its original value


# Calculate the final GLUE score
print("Calculating GLUE score...")
glue_metric = hf_datasets.load_metric('glue', task_name)
references = test_split_class_list
predictions = test_predictions_class_list
results = glue_metric.compute(predictions=predictions, references=references)
# Filename for outputting the current model's GLUE score for the current task
glue_score_output_filename = filename_prefix + '_' + 'GLUE_score.txt'
# Print the GLUE score to a file
with open(glue_score_output_filename, 'w') as f:
  sys.stdout = f # Change the standard output to the file we created.
  print(results)
  sys.stdout = original_stdout # Reset the standard output to its original value


print("=== DONE")
end_time = time.time()

# Calcuate the total runtime
total_runtime = end_time - start_time
print("TOTAL RUNTIME (seconds): " + str(total_runtime))