 =============================
 ===== PRELIMINARY SETUP =====
 =============================
0. System requirements:
   - NVIDIA GPU with the capability to run the CUDA toolkit
1. Install Anaconda and TensorFlow on your machine. Detailed step-by-step instructions on how to install both and verify your installs can be found here: `https://www.tensorflow.org/install/pip#windows-native_1` (be sure to select the tab with your respective operating system at the top before following the instructions)
2. Open the Anaconda environment you created for TensorFlow in the previous step.
3. Follow the instructions in the `Setup` section in this link all the way until you complete the `pip install -U tfds-nightly` command to download the other relevant libraries you need to run this script: `https://www.tensorflow.org/text/tutorials/bert_glue`
4. Install the Huggingface datasets library by following the instructions in this link: `https://huggingface.co/docs/datasets/installation` (be sure to follow the instructions to install with pip)
   - This will be used for the final calculation of the GLUE scores for each task.

 ==============================
 ===== RUNNING THE SCRIPT =====
 ==============================
 - You will need to edit the script file before each task you run to set the current model and task to run.
 - Be sure to run the script in the TensorFlow environment you set up in the previous section.
1. Under the section labeled `SET THE BERT MODEL NAME`, on line 51, change the value of the `bert_model_name` string to one of the entries in the `map_name_to_handle` dict. For an example, you can view the current value of that string in the script.
2. Under the section labeled `SET THE TASK NAME HERE`, on line 459, change the value of the `task_name` string to one of the following depending on the task you want to run for your chosen model:
   - cola
   - mrpc
   - qnli
   - qqp
   - rte
   - sst2
   - wnli
3. In your TensorFlow Anaconda environment, run `run_bert_tasks.py` after making the above edits. Make sure you're running using python3.

 ========================
 ===== OUTPUT FILES =====
 ========================
 - The script will output a variety of files, each with the format `modelname__taskname__outputfile.txt`
 - `modelname__taskname__test_split_labels_prerun.txt`: The raw labels for the original classifications for each of the test dataset samples, before the model has classified them
 - `modelname__taskname__returned_info.txt`: The raw labels for the original classifications for each of the test dataset samples paired with the actual samples themselves and their indices, before the model has classified them
 - `modelname__taskname__model-classified.txt`: The raw label output from the model for each of the samples in the test dataset
 - `modelname__taskname__test_run_results.txt`: The outputs of the model's classifications for each of the test samples, with the test sample and raw results printed alongside the classification
 - `modelname__taskname__GLUE_score.txt`: The chosen model's GLUE score for the given task after fine-tuning and running on the test dataset.